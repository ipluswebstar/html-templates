/* ================================================
----------- Porto ---------- */
(function ($) {
	"use strict";
	var Porto = {
		initialised: false,
		version: 1.0,
		mobile: false,
		bannerContainer: $('#banner-container'),
		init: function () {

			if(!this.initialised) {
				this.initialised = true;
			} else {
				return;
			}

			// Call Porto Functions
			this.checkMobile();
			this.scrollAnimations();
			this.menuHover();
			this.searchPopup();
			this.menuDisplay();
			this.productHover();
			this.sideMenuCollapse();
			this.scrollToTopAnimation();
			this.scrollToClass();
			this.productZoomImage();
			this.boostrapSpinner();
			this.tooltip();
			this.popover();
			this.parallax();

			/* Call function if Owl Carousel plugin is included */
			if ( $.fn.owlCarousel ) {
				this.owlCarousels();
			}

			/* Call function if Media noUiSlider plugin is included */
			if ($.fn.noUiSlider) {
				this.priceSlider();
			}

			var self = this;
			/* Imagesloaded plugin included in isotope.pkgd.min.js */
			/* Banners Masonry index2 */
			if (typeof imagesLoaded === 'function') {

				/* check images for blog masonry/grid */
				imagesLoaded(self.bannerContainer, function() {
					self.bannerMasonry();
				});
			}

		},
		checkMobile: function () {
			/* Mobile Detect*/
			if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
				this.mobile = true;
			} else {
				this.mobile = false;
			}
		},
		productHover: function () {
			/* Fallback for small screent if product width <= 195px prevent btns from overflow */
			$('.product').on('mouseover', function () {
				var productW = $(this).width();

				if (productW <= 195) {
					$(this).find('.btn-add-cart').addClass('small');
				}
			}).on('mouseleave', function () {
				$(this).find('.btn-add-cart').removeClass('small');
			});
		},
		menuHover: function () {
			// Sub menu show/hide with hoverIntent plugin
			if ($.fn.hoverIntent) {
				$('ul.menu').hoverIntent({
					over: function() {
						$(this).addClass('open');

					},
					out: function() {
						$(this).removeClass('open');
					},
					selector: 'li',
					timeout: 80, // lower or upper this value to speed 
					interval: 55
				});
			}
		},
		searchPopup : function () {
			$('.search-toggle').on('click', function (e) {
				$('.searchform').toggleClass('opened');
				e.preventDefault();
			});
		},
		sideMenuCollapse: function () {
			/* toggle side menu + mobile menu sub menus */
			$('.accordion-menu').find('.arrow').on('click', function(e) {

				if ($(this).closest('li').find('ul').length) {
					$(this).closest('li').children('ul').slideToggle(350, function () {
						$(this).closest('li').toggleClass('open');
					});
					e.preventDefault();
				} else {
					return;
				}

			});
		},
		menuDisplay: function () {
			// Menu Display via btn (see: index4.hmtl)
			$('.mobile-toggle, #mobile-menu-overlay').on('click', function (e) {
				$('body').toggleClass('opened-menu');
				e.preventDefault();
			});	
		},
		owlCarousels: function () {
			var self = this;

			/* New Arrivals carousel - (index17.html - homepage) */
			$('.owl-carousel.index17-featured-carousel').owlCarousel({
				loop:false,
				margin:20,
				responsiveClass:true,
				nav:false,
				navText: ['<i class="fa fa-chevron-left">', '<i class="fa fa-chevron-right">'],
				dots: false,
				autoplay: true,
				autoplayTimeout: 12000,
				responsive:{
					0:{
						items:1
					},
					480: {
						items:2
					},
					768:{
						items:3
					},
					992: {
						items:4
					},
					1200: {
						items:5
					}
				}
			});

			/* New Arrivals carousel - (index17.html - homepage) */
			$('.owl-carousel.index17-arrivals-carousel').owlCarousel({
				loop:false,
				margin:20,
				responsiveClass:true,
				nav:false,
				navText: ['<i class="fa fa-chevron-left">', '<i class="fa fa-chevron-right">'],
				dots: false,
				autoplay: true,
				autoplayTimeout: 12000,
				responsive:{
					0:{
						items:1
					},
					480: {
						items:2
					},
					768:{
						items:3
					},
					992: {
						items:4
					},
					1200: {
						items:5
					}
				}
			});

			/* Blog post carousel - (index17.html - homepage) */
			$('.owl-carousel.from-blog-posts').owlCarousel({
				loop:false,
				margin:20,
				responsiveClass:true,
				nav:false,
				navText: ['<i class="fa fa-chevron-left">', '<i class="fa fa-chevron-right">'],
				dots: false,
				autoplay: true,
				autoplayTimeout: 12000,
				responsive:{
					0:{
						items:1
					},
					480: {
						items:2
					}
				}
			});

			/* Featured carousel - (index14.html - homepage) */
			$('.owl-carousel.parallax-featured-carousel').owlCarousel({
				loop:false,
				margin:20,
				responsiveClass:true,
				nav:false,
				navText: ['<i class="fa fa-chevron-left">', '<i class="fa fa-chevron-right">'],
				dots: true,
				autoplay: true,
				autoplayTimeout: 12000,
				responsive:{
					0:{
						items:1
					},
					480: {
						items:2
					},
					768:{
						items:3
					},
					992: {
						items:4
					},
					1200: {
						items:5
					}
				}
			});

			/* Featured carousel - (index14.html - homepage) */
			$('.owl-carousel.parallax-featured-carousel-two').owlCarousel({
				loop:false,
				margin:20,
				responsiveClass:true,
				nav:false,
				navText: ['<i class="fa fa-chevron-left">', '<i class="fa fa-chevron-right">'],
				dots: true,
				autoplay: true,
				autoplayTimeout: 12000,
				responsive:{
					0:{
						items:1
					},
					480: {
						items:2
					},
					768:{
						items:3
					},
					992: {
						items:4
					},
					1200: {
						items:5
					}
				}
			});

			/* New Arrivals carousel - (index13.html - homepage) */
			$('.owl-carousel.index13-arrivals-carousel').owlCarousel({
				loop:false,
				margin:20,
				responsiveClass:true,
				nav:true,
				navText: ['<i class="fa fa-chevron-left">', '<i class="fa fa-chevron-right">'],
				dots: false,
				autoplay: true,
				autoplayTimeout: 12000,
				responsive:{
					0:{
						items:1
					},
					480: {
						items:2
					},
					600: {
						item:3
					},
					768:{
						items:4
					},
					992: {
						items:5
					},
					1200: {
						items:6
					}
				}
			});

			/*Tab Featured carousel - (index11.html - homepage) */
			$('.owl-carousel.tab-featured-carousel').owlCarousel({
				loop:false,
				margin:20,
				responsiveClass:true,
				nav:true,
				navText: ['<i class="fa fa-chevron-left">', '<i class="fa fa-chevron-right">'],
				dots: false,
				autoplay: true,
				autoplayTimeout: 12000,
				responsive:{
					0:{
						items:1
					},
					480: {
						items:2
					},
					768:{
						items:3
					},
					992: {
						items:4
					},
					1200: {
						items:5
					}
				}
			});

			/* Tab Latest carousel - (index11.html - homepage) */
			$('.owl-carousel.tab-latest-carousel').owlCarousel({
				loop:false,
				margin:20,
				responsiveClass:true,
				nav:true,
				navText: ['<i class="fa fa-chevron-left">', '<i class="fa fa-chevron-right">'],
				dots: false,
				autoplay: true,
				autoplayTimeout: 11000,
				responsive:{
					0:{
						items:1
					},
					480: {
						items:2
					},
					768:{
						items:3
					},
					992: {
						items:4
					},
					1200: {
						items:5
					}
				}
			});

			/* index11.html - Clients - brands carousel 2 */
			$('.owl-carousel.brands-carousel2').owlCarousel({
				loop:true,
				margin:20,
				responsiveClass:true,
				nav:true,
				navText: ['<i class="fa fa-chevron-left">', '<i class="fa fa-chevron-right">'],
				dots: false,
				autoplay: true,
				autoplayTimeout: 8000,
				responsive:{
					0: {
						items:2
					},
					480: {
						items:3
					},
					768: {
						items:4
					},
					992: {
						items:5
					},
					1200: {
						items:6
					}
				}
			});

			/* Product.html -  Product carousel to zoom product section */
			$('.owl-carousel.product-gallery').owlCarousel({
	            loop:false,
				margin:8,
				responsiveClass:true,
				nav:false,
				dots: false,
				autoplay: true,
				autoplayTimeout: 10000,
				responsive:{
					0:{
						items:4
					}
				}
	        });

			/* index - Post Slider */
			$('.owl-carousel.post-slider').owlCarousel({
				loop:true,
				margin:0,
				items:1,
				responsiveClass:true,
				nav:false,
				navText: ['Previous', 'Next'],
				dots: true,
				autoplay: true,
				autoplayTimeout: 10000,
			});

			/* index - Sidebar banner Slider */
			$('.owl-carousel.widget-banner-slider').owlCarousel({
				loop:true,
				margin:0,
				items:1,
				responsiveClass:true,
				nav:false,
				navText: ['Previous', 'Next'],
				dots: true,
				autoplay: true,
				autoplayTimeout: 14000,
			});

			/* Home Product carousel - (index.html - homepage) */
			$('.owl-carousel.home-products-carousel').owlCarousel({
				loop:false,
				margin:16,
				responsiveClass:true,
				nav:true,
				navText: ['<i class="fa fa-chevron-left">', '<i class="fa fa-chevron-right">'],
				dots: false,
				autoplay: true,
				autoplayTimeout: 10000,
				responsive:{
					0:{
						items:1
					},
					480: {
						items:2
					},
					768:{
						items:4
					}
				}
			});

			/* Product newarrivals carousel  - (index2.html - homepage) */
			$('.owl-carousel.just-arrivals-carousel').owlCarousel({
				loop:false,
				margin:16,
				responsiveClass:true,
				nav:true,
				navText: ['<i class="fa fa-chevron-left">', '<i class="fa fa-chevron-right">'],
				dots: false,
				autoplay: true,
				autoplayTimeout: 10000,
				responsive:{
					0:{
						items:1
					},
					480: {
						items:2
					},
					768:{
						items:3
					},
					992:{
						items:4
					},
					1200:{
						items:5
					}
				}
			});

			/* Colection carousel - (index6.html - homepage) */
			$('.owl-carousel.collection-carousel').owlCarousel({
				loop:false,
				margin:30,
				responsiveClass:true,
				nav:false,
				dots: true,
				autoplay: true,
				autoplayTimeout: 10000,
				responsive:{
					0:{
						items:1
					},
					480: {
						items:2
					}
				}
			});

			/* Colection carousel long - (index6.html - homepage) */
			$('.owl-carousel.collection-carousel-long').owlCarousel({
				loop:false,
				margin:16,
				responsiveClass:true,
				nav:false,
				dots: true,
				autoplay: true,
				autoplayTimeout: 10000,
				responsive:{
					0:{
						items:1
					},
					480: {
						items:2
					},
					768:{
						items:4
					},
					1200:{
						items:5
					}
				}
			});

			/* index.html - Clients -partners carousel  */
			$('.owl-carousel.brands-carousel').owlCarousel({
				loop:true,
				margin:30,
				responsiveClass:true,
				nav:false,
				dots: true,
				autoplay: true,
				autoplayTimeout: 8000,
				responsive:{
					0:{
						items:2
					},
					480: {
						items:3
					},
					768: {
						items:4
					},
					992:{
						items:5
					}
				}
			});

			/* Product featured carousel  - (index7.html - homepage) */
			$('.owl-carousel.featured-product-carousel').owlCarousel({
				loop:false,
				margin:25,
				responsiveClass:true,
				nav:true,
				navText: ['<i class="fa fa-chevron-left">', '<i class="fa fa-chevron-right">'],
				dots: false,
				autoplay: true,
				autoplayTimeout: 12000,
				responsive:{
					0:{
						items:1
					},
					480: {
						items:2
					},
					768:{
						items:3
					},
					992:{
						items:4
					}
				}
			});

			/* banner/category carousel  - (index7.html - homepage) */
			$('.owl-carousel.banners-carousel').owlCarousel({
				loop:false,
				margin:20,
				responsiveClass:true,
				nav:true,
				navText: ['<i class="fa fa-chevron-left">', '<i class="fa fa-chevron-right">'],
				dots: false,
				autoplay: true,
				autoplayTimeout: 12000,
				responsive:{
					0:{
						items:1
					},
					480: {
						items:2
					},
					768:{
						items:3
					},
					992:{
						items:4
					}
				}
			});

			/* blog post carousel  - (index7.html - homepage) */
			$('.owl-carousel.post-carousel').owlCarousel({
				loop:false,
				margin:20,
				responsiveClass:true,
				nav:false,
				navText: ['<i class="fa fa-chevron-left">', '<i class="fa fa-chevron-right">'],
				dots: true,
				autoplay: true,
				autoplayTimeout: 12000,
				responsive:{
					0:{
						items:1
					},
					480: {
						items:2
					}
				}
			});

			/* index7 - Testimonials carousel */
			$('.owl-carousel.testimonial-carousel').owlCarousel({
				loop:false,
				margin:0,
				items:1,
				responsiveClass:true,
				nav:false,
				navText: ['Previous', 'Next'],
				dots: true,
				autoplay: true,
				autoplayTimeout: 10000
			});


			/* index5 - Products Slider */
			$('.owl-carousel.product-slider').owlCarousel({
				loop:false,
				margin:0,
				items:1,
				responsiveClass:true,
				nav:false,
				navText: ['Previous', 'Next'],
				dots: true,
				autoplay: true,
				autoplayTimeout: 9000,
			});

			/* product 4 col carousel  - (index4.html - homepage) */
			$('.owl-carousel.product-4col-carousel').owlCarousel({
				loop:false,
				margin:20,
				responsiveClass:true,
				nav:true,
				navText: ['<i class="fa fa-chevron-left">', '<i class="fa fa-chevron-right">'],
				dots: false,
				autoplay: true,
				autoplayTimeout: 12000,
				responsive:{
					0:{
						items:1
					},
					480: {
						items:2
					},
					768:{
						items:3
					},
					992:{
						items:4
					}
				}
			});

			/* index4 - info Slider */
			$('.owl-carousel.info-carousel').owlCarousel({
				loop:false,
				margin:0,
				items:1,
				responsiveClass:true,
				nav:false,
				navText: ['Previous', 'Next'],
				dots: true,
				autoplay: true,
				autoplayTimeout: 14000,
			});

			/* product 6 col carousel  - (index4.html - homepage) */
			$('.owl-carousel.product-6col-carousel').owlCarousel({
				loop:false,
				margin:12,
				responsiveClass:true,
				nav:true,
				navText: ['<i class="fa fa-chevron-left">', '<i class="fa fa-chevron-right">'],
				dots: false,
				autoplay: true,
				autoplayTimeout: 10000,
				responsive:{
					0:{
						items:2
					},
					480: {
						items:3
					},
					768:{
						items:4
					},
					992:{
						items:5
					},
					1200:{
						items:6
					}
				}
			});

			/* Colection carousel long - (index9.html - homepage) */
			$('.owl-carousel.selection-carousel').owlCarousel({
				loop:false,
				margin:20,
				responsiveClass:true,
				nav:true,
				navText: ['<i class="fa fa-chevron-left">', '<i class="fa fa-chevron-right">'],
				dots: false,
				autoplay: true,
				autoplayTimeout: 10000,
				responsive:{
					0:{
						items:1
					},
					480: {
						items:2
					},
					768:{
						items:4
					}
				}
			});

		},
		scrollTopBtnAppear: function () {
			// This will be triggered at the bottom of code with window scroll event
			var windowTop = $(window).scrollTop(),
		            scrollTop = $('#scroll-top');

	        if (windowTop >= 300) {
	            scrollTop.addClass('fixed');
	        } else {
	            scrollTop.removeClass('fixed');
	        }
		    
		},
		scrollToAnimation: function (speed, offset, e) {
			/* General scroll to function */
			var targetEl = $(this).attr('href'),
				toTop = false;

			if (!$(targetEl).length) {
				if (targetEl === '#header' || targetEl === '#top' || targetEl === '#wrapper') {
					targetPos = 0;
					toTop = true;
				} else {
					return;
				}
			} else {
				var elem = $(targetEl),
					targetPos = offset ? ( elem.offset().top + offset ) : elem.offset().top;
			}
			
			if (targetEl || toTop) {
				$('html, body').animate({
		            'scrollTop': targetPos
		        }, speed || 1200);
		        e.preventDefault();
			}
		},
		scrollToTopAnimation: function () {
			var self = this;
			// Scroll to top animation when the scroll-top button is clicked
			$('#scroll-top').on('click', function (e) {
		        self.scrollToAnimation.call(this, 1200, 0, e);
		    });
		},
		scrollToClass: function () {
			var self = this;
			// Scroll to animation - predefined class
			// Just add this class to any element and 
			// add href attribute with target id (#targer like so ) for target 
			// you can change 0 offset to -60 (height of fixed header)
			$('.scrollto, .section-btn').on('click', function (e) {
		        self.scrollToAnimation.call(this, 1200, 0, e);
		    });
		},
		priceSlider:function () {
			// Slider For category pages / filter price
			$('#price-range').noUiSlider({
				start: [0, 35],
				handles: 2,
				connect: true,
				range: {
					'min': 0,
					'max': 35
				}
			});

			$("#price-range").Link('lower').to( $('#slider-low-value') )
			$("#price-range").Link('upper').to( $('#slider-high-value') );
		},
		productZoomImage: function () {
			var self = this;
			// Product page zoom plugin settings
			if ($.fn.elevateZoom) {
				$('#product-zoom').elevateZoom({
					responsive: true,
					zoomType: 'inner', // lens or window can be used - options already set below
					borderColour: '#d0d0d0',
					zoomWindowPosition: 1,
					zoomWindowOffetx: 30,
					cursor: "crosshair", //
					zoomWindowFadeIn: 400,
					zoomWindowFadeOut: 250,
					lensBorderSize: 3, // lens border size
					lensOpacity: 1,
					lensColour: 'rgba(255, 255, 255, 0.5)', // lens color
					lensShape : "square", // circle lens shape can be uses
					lensSize : 200,
					scrollZoom : true
				});

				/* swap images for zoom on click event */
				$('.product-gallery').find('a').on('click', function (e) {
					var ez = $('#product-zoom').data('elevateZoom'),
						smallImg = $(this).data('image'),
						bigImg = $(this).data('zoom-image');

						ez.swaptheimage(smallImg, bigImg);
					e.preventDefault();
				});
			}
		},
		boostrapSpinner: function () {
			// Custom spinners
			// Include jquery.bootstrap-touchspin.min.min.js file
			if ($.fn.TouchSpin) {
				// Vertical Spinner
				$(".vertical-spinner").TouchSpin({
					verticalbuttons: true,
					verticalupclass: 'customup',
					verticaldownclass: 'customdown'
				});

				//Horizontal spinner
				$(".horizontal-spinner").TouchSpin();
			}
		},
		tooltip: function () {
			// Bootstrap tooltip
			if($.fn.tooltip) {
				$('.add-tooltip').tooltip();
			}
		},
		popover: function () {
			// Bootstrap tooltip
			if($.fn.popover) {
				$('.add-popover').popover({
					trigger: 'focus'
				});
			}
		},
		scrollAnimations: function () {

			/* 	// Wowy Plugin
				Add Html elements wow and animation class 
				And you can add duration via data attributes
				data-wow-duration: Change the animation duration
				data-wow-delay: Delay before the animation starts
				data-wow-offset: Distance to start the animation (related to the browser bottom)
				data-wow-iteration: Number of times the animation is repeated
			*/

			// Check for class WOW // You need to call wow.min.js and animate.css for scroll animations to work
			if (typeof WOW === 'function') {
				new WOW({
					boxClass:     'wow',      // default
					animateClass: 'animated', // default
					offset:       0          // default
				}).init();
			}

		},
		parallax: function () {
			// Parallax - if not mobile  with skrollr js plugin 
			if ( !this.mobile && typeof skrollr === 'object') {
				skrollr.init({
					forceHeight: false
				});
			} 

			if ( this.mobile ) {
				/* if mobile, delete background attachment fixed from parallax class */
				$('.parallax, .parallax-fixed').css('background-attachment', 'initial')
			}

		},
		bannerMasonry: function () {
			/* Masonry - Grid for blog pages with isotope.pkgd.min.js file */

			// This is defined at the top of the this file
			var bannerContainer = this.bannerContainer;

			bannerContainer.isotope({
				itemSelector: '.banner',
				masonry: {
					columnWidth: '.grid-sizer',
					gutter: 0
				}
			});
		},

	};

	Porto.init();

	// Load Event
	$(window).on('load', function() {

	});

	// Scroll Event
	$(window).on('scroll', function () {
		/* Display Scrol to Top Button */
		Porto.scrollTopBtnAppear();

	});

	// Resize Event 
	// Smart resize if plugin not found window resize event
	if($.event.special.debouncedresize) {
		$(window).on('debouncedresize', function() {


	    });
	} else {
		$(window).on('resize', function () {


		});
	}

	/* Do not delete - this is trigger for owl carousels which used in bootstrap tab plugin */
	/* This is update for carousels  example (product.html) */
    $('.nav-links').find('a[data-toggle="tab"]').on('shown.bs.tab', function (event) {
		/* Trigger resize event for to owl carousels fit */
		var evt = document.createEvent('UIEvents');
		evt.initUIEvent('resize', true, false,window,0);
		window.dispatchEvent(evt);
    });

})(jQuery);